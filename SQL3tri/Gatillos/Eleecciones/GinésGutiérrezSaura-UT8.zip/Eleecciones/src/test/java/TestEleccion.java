import org.example.Main;
import org.example.Votos;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestEleccion {
    @Test
    public void testClasificanEnSuLugar() {
        Votos votos = new Votos();
        assertAll(
                () -> assertEquals("A FAVOR",votos.clasificarVotos("nombre","A FAVOR",3)),
                ()-> assertEquals("EN CONTRA",votos.clasificarVotos("nombre","EN CONTRA",3)),
                ()-> assertEquals("ABSTENCION",votos.clasificarVotos("nombre","ABSTENCION",3))
        );
    }
    @Test
    public void testContarVotos(){
        Votos votos = new Votos();
        votos.clasificarVotos("nombre","A FAVOR",5);
        votos.clasificarVotos("nombre","EN CONTRA",3);
        votos.clasificarVotos("nombre","ABSTENCION",2);

        assertAll(
                () -> assertEquals(5,votos.getVotosAFavor()),
                ()-> assertEquals(3,votos.getVotosEnContra()),
                ()-> assertEquals(2,votos.getVotosAbstencion())
        );
    }
    @Test
    public void testComprobarNomrbes(){
        Votos votos = new Votos();
        votos.clasificarVotos("Paco","A FAVOR",5);
        votos.clasificarVotos("Rubiales","A FAVOR",8);
        votos.clasificarVotos("Ramiro","EN CONTRA",3);
        votos.clasificarVotos("Pete","ABSTENCION",2);
        votos.clasificarVotos("Hola","ABSTENCION",2);
        votos.clasificarVotos("Elvis","ABSTENCION",2);

        assertAll(
                () -> assertEquals("[Paco, Rubiales]",votos.getNombresAFavor()),
                ()-> assertEquals("[Ramiro]",votos.getNombresEnContra()),
                ()-> assertEquals("[Pete, Hola, Elvis]",votos.getNombresAbstencion())
        );
    }
    @Test
    public void testResultadoAceptado(){
        Votos votos = new Votos();
        votos.clasificarVotos("Paco","A FAVOR",5);
        votos.clasificarVotos("Rubiales","A FAVOR",8);
        votos.clasificarVotos("Ramiro","EN CONTRA",3);

        assertEquals("La propuesta ha sido aceptada",votos.calcularResultado());
    }
    @Test
    public void testResultadoRechazado(){
        Votos votos = new Votos();
        votos.clasificarVotos("Paco","A FAVOR",5);
        votos.clasificarVotos("Moro","EN CONTRA",8);
        votos.clasificarVotos("Ramiro","EN CONTRA",34);

        assertEquals("La propuesta ha sido rechazada",votos.calcularResultado());
    }
}
